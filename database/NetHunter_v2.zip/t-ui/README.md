## NetHunter Theme Version 2.0

### Make your phone like a cool looking terminal with green font colors. A theme for T-UI Expert Launcher inspired by the Kali NetHunter distribution.

**New Features:**
* `chwf`: A script to easily customize weather data.
* `sysinfo`: Display system information with an ascii art logo.
* `banner-custom`: Want to display a custom banner? Just edit custom_banner.txt inside the t-ui/ascii directory and then run this command.
* New matching wallpaper.

**Changes:**
* Enabled weather status
* Enabled output field and status lines borders
* Changed the design of banners
* Input area is now on top of the output field
* Changed icons for WiFi, RAM, and  internal storage
* Font: Now using regular typeface
* Some color adjustments to reduce eye strain
