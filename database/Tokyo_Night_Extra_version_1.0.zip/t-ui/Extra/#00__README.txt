
▀▀█▀▀ █▀▀█ █░█ █░░█ █▀▀█ 　 █▀▀▄ ░▀░ █▀▀▀ █░░█ ▀▀█▀▀ 
░░█░░ █░░█ █▀▄ █▄▄█ █░░█ 　 █░░█ ▀█▀ █░▀█ █▀▀█ ░░█░░ 
░░▀░░ ▀▀▀▀ ▀░▀ ▄▄▄█ ▀▀▀▀ 　 ▀░░▀ ▀▀▀ ▀▀▀▀ ▀░░▀ ░░▀░░
              			  
					  
  ___     ___  __                ___  __   __     __       
 |__  \_/  |  |__)  /\     \  / |__  |__) /__` | /  \ |\ | 
 |___ / \  |  |  \ /~~\     \/  |___ |  \ .__/ | \__/ | \| 
                                                          																								
by E M A   ((Telegram: @UnderTheGun1 --  GitHub: github.com/M4dGun))
																									
1) unzip and move the t-ui folder inside the internal memory (/sdcard or /storage/emulated/0)

2) open /t-ui/Extra folder and install the first apk file, named: #01__KLWP Live Wallpaper Maker_v3.55b112309.xapk

3) in the same folder, now install the other apk file, named: #02__org-kustom-wallpaper-p.apk

4) now start KLWP, grant the various permissions, click on the "IMPORT" button, locate the /t-ui/Extra folder and import the Tokyo_Night_Extra.klwp theme; press the "save" button and if the "missing requirements" window appears press "FIX", then "set as wallpaper" and then select "home screen". Watch this video if you have difficulties, it summarizes this step: 

https://www.veed.io/view/d09f53d7-be24-4b0e-959a-ea6cf04ae3b8


5) Now that you have set the T-UI and KLWP themes, if you have a different display than mine, you will need to move and align the various widgets

6) To align the 4 widgets run KLWP, open the Tokyo Night theme configuration page, at the bottom you will see 4 lines, each line corresponds to an object. 

7) Start from the first object pressing on his name, move to the "POSITION" tab and with the XOffset and YOffset buttons align the object. Press the "save" button at the top (it has the shape of a floppy) to save the changes, go back to the T-UI home page and check the alignment. Repeat this operation until you are satisfied with the result and repeat this procedure for all the 4 widgets.

8) When you have aligned all the 4 objects, save your theme; I also recommend that you export it with the "Export Preset" button, by clicking on the hamburger icon at the top left.