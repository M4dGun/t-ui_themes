#!/bin/sh
## T-ui Theme Manager Installer
## Author   : Ema
## Github   : @M4dGun
## Telegram : @UnderTheGun1
## T-ui group: https://t.me/tuilauncher
##
## #####  #  #  #####"
##   #    #  #    #
##   #    #  #    #   
##   #    ####  #####
##
######
PROGNAME=ttm

tui=/storage/emulated/0/t-ui
sd=/storage/emulated/0
sdt=/storage/emulated/0/tui-themes_and_backup

REMOTEHOST="https://github.com/M4dGun/t-ui_themes/raw/main"
SCRIPT_LINK="https://raw.githubusercontent.com/M4dGun/t-ui_themes/main/theme-manager/ttm"

ALIASTXT="$tui/alias.txt"


	echo " T-ui Theme Manager Installer"
	printf "\n \n :.: Please wait... \n " ; sleep 1.0

	if [[(-f /bin/curl)]]; then
        cd $tui && curl -L $SCRIPT_LINK -o $tui/$FILENAME
    else
        cd $tui && wget -c $SCRIPT_LINK
	fi
	
	if [ $? -ne '0' ]; then
	printf "\n \n :.: Please run ttm-installer via Termux/TEL or another Terminal emulator: check wiki for more info. \n " ; exit 1
	fi
	printf "\n :.: Installing ttm... \n " ; sleep 1.5


   rm $sd/$PROGNAME &>/dev/null
   cd $tui && mv $PROGNAME $sd/$PROGNAME


	# Test if ttm alias already exist ##thank you @deadrabbit404
	grep "^ttm" $ALIASTXT >/dev/null 2>&1
	if [ $? -ne 0 ]
	then
		# Test if the file has no EOL, then print a blank line.
		[ -n "`tail -c 1 $ALIASTXT`" ] && echo >> $ALIASTXT 
		echo "ttm =sh $sd/$PROGNAME %" >> $ALIASTXT
		echo "ttm -p=search -u https://github.com/M4dGun/t-ui_themes" >> $ALIASTXT

		printf "\n :.: Added ttm alias in new alias.txt \n " ; sleep 1.5
	else
		# This means the alias already exists.
		# Replace whatever value assigned to the alias with a new one that points to the ttm script.
		sed -i "s#\(^ttm =\).*\$#\1sh $sd/$PROGNAME %#" $ALIASTXT
		printf "\n :.: ttm alias already exists, nothing to change \n " ; sleep 1.5
	fi

echo "\n ::: ttm installed ::: \n " ; sleep 1.5
echo "\n :.: Please restart or refresh t-ui. Enjoy"
