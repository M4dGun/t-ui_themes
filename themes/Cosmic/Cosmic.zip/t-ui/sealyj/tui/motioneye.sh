file="/storage/emulated/0/scripts/tui/motioneye.txt"
echo "Opening MotionEye"
curl --silent http://127.0.0.1:8080/server/motioneye/stream || echo "Failed to trigger automagic webserver"
sleep 0.1
cat /storage/emulated/0/scripts/tui/motioneye.txt
#echo "${output}"
