#!/bin/bash


wget -q "http://www.coe.neu.edu/cgi-bin/fortune"

sleep 1;

sed -n '/<pre>/,/<\/pre>/p' fortune | cat > fortune1

sed -i 's/<pre>/\ /g' fortune1

sed -i 's/<\/pre>/\ /g' fortune1

cat fortune1

rm fortune1 fortune
