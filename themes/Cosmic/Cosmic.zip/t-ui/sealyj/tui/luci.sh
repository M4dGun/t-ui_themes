file="/storage/emulated/0/scripts/tui/luci.txt"
echo "Opening LuCi"
curl --silent http://127.0.0.1:8080/luci || echo "Failed to trigger automagic webserver"
sleep 0.1
cat /storage/emulated/0/scripts/tui/luci.txt
#echo "${output}"
