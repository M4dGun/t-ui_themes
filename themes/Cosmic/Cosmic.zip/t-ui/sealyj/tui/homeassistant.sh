file="/storage/emulated/0/scripts/tui/homeassistant.txt"
echo "Opening Home Assistant"
echo $(date) > /storage/emulated/0/scripts/triggers/hass || curl --silent http://127.0.0.1:8080/server/hass/cameras
sleep 0.1
cat /storage/emulated/0/scripts/tui/homeassistant.txt
#echo "${output}"
